//
//  VVSwiftEnumCommenter.h
//  VVDocumenter-Xcode
//
//  Created by 王 巍 on 14-7-30.
//  Copyright (c) 2014年 OneV's Den. All rights reserved.
//

#import "VVBaseCommenter.h"

@interface VVSwiftEnumCommenter : VVBaseCommenter

@end
