//
//  IDEIndexCompletionStrategy+KSImageNamed.h
//  KSImageNamed
//
//  Created by Kent Sutherland on 1/19/13.
//
//

#import "XcodeMisc.h"

@interface IDEIndexCompletionStrategy (KSImageNamed)

@end
